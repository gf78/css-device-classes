<?php

/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              https://github.com/gf78/css-device-classes
 * @since             0.1
 * @package           css-device-classes
 *
 * @wordpress-plugin
 * Plugin Name:       css-device-classes
 * Plugin URI:        https://github.com/gf78/css-device-classes
 * Description:       Small, fast & simple javascript that provides CSS classes to control style and visibility of DOM elements for android, iphone and desktop devices.
 * Version:           1.0.0
 * Author:            Gregor Fischer
 * Author URI:        https://gf78.net/css-device-classes/
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 */

function css_device_classes() {
    echo "<!--CSS-Device-Classes--><script>try{h=document.getElementsByTagName('html')[0].classList;if(!h.contains('device-classes')){try{u=navigator.userAgent||navigator.vendor||window.opera;if(/android/i.test(u))h.add('device-classes','is-android','is-not-iphone','is-mobile','is-not-desktop');else if(/iPhone/i.test(u))h.add('device-classes','is-not-android','is-iphone','is-mobile','is-not-desktop');else h.add('device-classes','is-not-android','is-not-iphone','is-not-mobile','is-desktop');delete u}catch(e){h.add('device-classes','is-not-android','is-not-iphone','is-not-mobile','is-desktop')} s=document.createElement('style');s.type='text/css';s.innerHTML='.is-not-android .android-only, .is-not-iphone .iphone-only, .is-not-mobile .mobile-only, .is-not-desktop .desktop-only, .is-android .android-hide, .is-iphone .iphone-hide, .is-mobile .mobile-hide, .is-desktop .desktop-hide { display: none; }';document.getElementsByTagName('head')[0].appendChild(s);delete s} delete h}catch(e){}</script>";
}
add_action( 'wp_head', 'css_device_classes' );

?>



